img=imread('river.jpg');

gray=rgb2gray(img); 
hsv=rgb2hsv(img);

subplot(1,3,1),imshow(img), title('original image');
subplot(1,3,2),imshow(gray),title('gary image');
subplot(1,3,3),imshow(hsv), title('hsv image');