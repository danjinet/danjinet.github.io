clc;
clear all;
close all;

% Read the image
img = imread('moon.jpg');

% Display the original image
figure, imshow(img), title('Original Image');

% Convert RGB image to grayscale if it is not already grayscale
if size(img, 3) == 3
    img = rgb2gray(img);
end

% Apply median filtering to remove noise
filteredImg = medfilt2(img, [3 3]);  % Apply 3x3 median filter
figure, imshow(filteredImg), title('Image after Noise Removal');

% Apply Sobel edge detection
bwSobelImg = edge(filteredImg, 'sobel');  % Sobel edge detection
figure, imshow(bwSobelImg), title('Applying Sobel Operator Filter');