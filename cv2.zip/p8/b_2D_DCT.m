clc;
clear all;
close all;

% Read the image and convert to grayscale
file = imread('tire.tif');
if size(file, 3) == 3
    file = rgb2gray(file);  % Convert to grayscale if the image is RGB
end

file = im2double(file);  % Convert to double for DCT processing

% Compute the 8x8 DCT matrix
T = dctmtx(8);

% Pad the image so that its dimensions are divisible by 8
padded_size = ceil(size(file) / 8) * 8; % Find the next multiple of 8
padded_file = padarray(file, padded_size - size(file), 'post'); % Pad with zeros

% Block process the image using the DCT matrix
B = blockproc(padded_file, [8 8], @(block_struct) T * block_struct.data * T');

% Define a mask for quantization (example mask)
mask = [1 1 1 1 0 0 0 0;
        1 1 1 0 0 0 0 0;
        1 1 0 0 0 0 0 0;
        1 0 0 0 0 0 0 0;
        0 0 0 0 0 0 0 0;
        0 0 0 0 0 0 0 0;
        0 0 0 0 0 0 0 0;
        0 0 0 0 0 0 0 0];

% Apply the mask for quantization
B_quantized = blockproc(B, [8 8], @(block_struct) block_struct.data .* mask);

% Display the original and transformed images
subplot(1,2,1);
imshow(file, []);
title('Original Image');

subplot(1,2,2);
imshow(B_quantized, []);
title('DCT with Mask Applied');