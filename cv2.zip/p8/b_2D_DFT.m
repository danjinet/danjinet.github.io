clear all;
close all;
clc;

% Read and convert the image to double
a = imread('astronautonmoonwalk.jpg');
a = rgb2gray(a);  % Convert to grayscale
a = double(a);

% Get the size of the image
[row, col] = size(a);
const = sqrt(row * col);

% DFT calculation using the formula
W = zeros(row, col);  % Preallocate the matrix for W
for n = 0:row-1
    for k = 0:col-1
        W(n+1, k+1) = exp(-1i * 2 * pi * n * k / const);
    end
end

X = W * a * W.';  % Applying the DFT formula: F = T * f * T'

% Using the built-in fft2 function for comparison
ff = fft2(a);

% Display the original image
figure(1);
imshow(uint8(a));
title('Original Image');

% Display the DFT using the custom formula
figure(2);
colormap(gray);
imagesc(fftshift(log(1 + abs(X))));
title('DFT by Formula');

% Display the DFT using fft2
figure(3);
colormap(gray);
imagesc(fftshift(log(1 + abs(ff))));
title('DFT by fft2');