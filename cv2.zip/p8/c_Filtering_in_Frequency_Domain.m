clc;
clear all;
close all;

% Read the input image
img = imread('horse.jpg');

% Display original image
subplot(2, 2, 1);
imshow(img);
title('Input Image');

% Gaussian Low Pass Filter
hsize = [6 6];
sigma = 5;
filter = fspecial('gaussian', hsize, sigma);
filteredImage = imfilter(img, filter);

subplot(2, 2, 2);
imshow(filteredImage);
title('Filtered Image (Gaussian LPF)');

% Ideal High Pass Filter using FFT
figure;
img_gray = rgb2gray(img); % Convert to grayscale for FFT processing
F = fft2(double(img_gray)); % Apply FFT
Fshift = fftshift(F); % Shift zero frequency to center

% Create ideal high pass filter mask
[rows, cols] = size(img_gray);
cx = cols/2;
cy = rows/2;
D0 = 30; % Cutoff frequency
H = ones(rows, cols);
for i = 1:rows
    for j = 1:cols
        D = sqrt((i - cy)^2 + (j - cx)^2);
        if D < D0
            H(i, j) = 0;
        end
    end
end

% Apply the mask to the frequency domain image
G = Fshift .* H;

% Inverse FFT to get the high pass filtered image
G = ifftshift(G); % Inverse shift
filteredImageHP = real(ifft2(G));

subplot(2, 2, 1);
imshow(img_gray);
title('Input Image (Grayscale)');

subplot(2, 2, 2);
imshow(filteredImageHP, []);
title('Filtered Image (Ideal HPF)');

% Ideal Low Pass Filter using FFT
figure;
Fshift = fftshift(F); % Shift zero frequency to center

% Create ideal low pass filter mask
H = zeros(rows, cols);
for i = 1:rows
    for j = 1:cols
        D = sqrt((i - cy)^2 + (j - cx)^2);
        if D < D0
            H(i, j) = 1;
        end
    end
end

% Apply the mask to the frequency domain image
G = Fshift .* H;

% Inverse FFT to get the low pass filtered image
G = ifftshift(G); % Inverse shift
filteredImageLP = real(ifft2(G));

subplot(2, 2, 1);
imshow(img_gray);
title('Input Image (Grayscale)');

subplot(2, 2, 2);
imshow(filteredImageLP, []);
title('Filtered Image (Ideal LPF)');