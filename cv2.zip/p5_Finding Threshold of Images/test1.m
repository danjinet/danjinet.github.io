% Clear previous data
clear all;
clc;
close all;

% Read the grayscale image from your local folder
grayImage = imread('/MATLAB Drive/cv/p5_Finding Threshold of Images/download.jpeg');  % Replace with your file name

% Check if the image is grayscale by confirming it has only 2 dimensions
if size(grayImage, 3) == 1
    % Convert Grayscale to RGB by replicating the grayscale values into 3 channels
    rgbImage = cat(3, grayImage, grayImage, grayImage);
else
    disp('The image is already in RGB format');
    return;
end

% Display the grayscale image
figure;
subplot(1, 2, 1);
imshow(grayImage);
title('Original Grayscale Image');

% Display the converted RGB image (will appear the same but in RGB format)
subplot(1, 2, 2);
imshow(rgbImage);
title('Converted RGB Image');