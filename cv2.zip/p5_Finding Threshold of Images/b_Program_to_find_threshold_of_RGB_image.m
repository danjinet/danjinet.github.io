clc;
close all;

% Load the image
im = imread('sunflower.jpg');

% Convert image to grayscale for thresholding
grayIm = rgb2gray(im);

% Get the dimensions of the grayscale image
[r, c] = size(grayIm);

% Initialize the thresholded image (b)
b = double(grayIm);

% Input the threshold value
t = input('Enter threshold value: ');

% Apply the threshold
for x = 1:r
    for y = 1:c
        if grayIm(x, y) < t
            b(x, y) = 0;   % Set pixel to black if below threshold
        else
            b(x, y) = 255; % Set pixel to white if above threshold
        end
    end
end

% Display the original image
figure(1);
imshow(im);
title('Original Image');

% Display the thresholded image
figure(2);
imshow(uint8(b));
title('Thresholded Image');