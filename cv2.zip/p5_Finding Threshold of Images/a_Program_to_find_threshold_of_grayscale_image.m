clear all;
clc;
close all;

% Read the image
im = imread('tire.jpg');

% Convert the image to double for processing
b = double(im);

% Get the dimensions of the image
[r, c] = size(im);

% Input the threshold value from the user
t = input('Enter threshold value: ');

% Apply thresholding to the image
for x = 1:r
    for y = 1:c
        if im(x, y) < t
            b(x, y) = 0;   % Set pixel to black if below threshold
        else
            b(x, y) = 255; % Set pixel to white if above threshold
        end
    end
end

% Clear figure windows to avoid overlapping titles
clf;

% Display the original image with the correct title
figure(1);
imshow(im);
title('Original Image');

% Display the thresholded image with the correct title
figure(2);
imshow(uint8(b));
title('Thresholded Image');