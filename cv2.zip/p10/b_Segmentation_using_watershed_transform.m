clc;
clear all;
close all;

% Read the grayscale image
img = rgb2gray(imread('Dogincar.jpg'));

% Apply morphological gradient to highlight the edges
gradImg = imgradient(img);

% Perform watershed transform
L = watershed(gradImg);

% Create a binary mask for watershed lines
mask = L == 0;

% Display the results
figure;
subplot(1, 3, 1);
imshow(img);
title('Original Grayscale Image');

subplot(1, 3, 2);
imshow(gradImg, []);
title('Gradient Magnitude');

subplot(1, 3, 3);
imshow(mask);
title('Watershed Segmentation');