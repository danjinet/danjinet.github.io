clc;
clear all;
close all;

% Read the grayscale image
img = rgb2gray(imread('Manonbeach.jpg'));

% Define Haar wavelet filters
lowPass = [1/sqrt(2), 1/sqrt(2)];  % Haar low-pass filter
highPass = [1/sqrt(2), -1/sqrt(2)]; % Haar high-pass filter

% Apply separable 1D DWT to rows
lowImg = conv2(img, lowPass', 'same');  % Low-pass on rows
highImg = conv2(img, highPass', 'same'); % High-pass on rows

% Apply separable 1D DWT to columns
cA = conv2(lowImg, lowPass, 'same');    % Approximation (Low-Low)
cH = conv2(lowImg, highPass, 'same');   % Horizontal detail (Low-High)
cV = conv2(highImg, lowPass, 'same');   % Vertical detail (High-Low)
cD = conv2(highImg, highPass, 'same');  % Diagonal detail (High-High)

% Display the approximation and detail coefficients
figure;
subplot(2, 2, 1);
imshow(mat2gray(cA));
title('Approximation (Low-Low)');

subplot(2, 2, 2);
imshow(mat2gray(cH));
title('Horizontal Detail (Low-High)');

subplot(2, 2, 3);
imshow(mat2gray(cV));
title('Vertical Detail (High-Low)');

subplot(2, 2, 4);
imshow(mat2gray(cD));
title('Diagonal Detail (High-High)');