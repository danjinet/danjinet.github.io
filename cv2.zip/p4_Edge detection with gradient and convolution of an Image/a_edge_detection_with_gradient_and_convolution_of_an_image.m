clc;
clear all;
close all;

img = imread('apple&beer.jpg');  % Load image
subplot(2,3,1);
imshow(img);
title('Original Image');

% Convert RGB image to grayscale
grayImg = rgb2gray(img);
subplot(2,3,2);
imshow(grayImg);
title('Grayscale Image');

% Apply median filter to remove noise
filteredImg = medfilt2(grayImg, [3 3]);  % Apply 3x3 median filter
subplot(2,3,3); 
imshow(filteredImg);
title('Image after Noise Removal');

% Perform Sobel edge detection
bwSobelImg = edge(filteredImg, 'sobel');  % Sobel edge detection
subplot(2,3,4); 
imshow(bwSobelImg);
title('Edge Detection (Sobel)');

% Define the mask for convolution
mask = [0 0 0 0 0;
        0 1 1 1 0;
        0 1 1 1 0;
        0 1 1 1 0;
        0 0 0 0 0];

% Perform 2D convolution
convImg = conv2(double(bwSobelImg), double(mask), 'same');  % Convolution
subplot(2,3,6); 
imshow(uint8(convImg));
title('Smoothing by Convolution');