clear all;
clc;

% Read the image
a = imread('angrycat.jpg');
b = double(a);

% Get the size of the image
[row, col] = size(b);

% Input for mask size
m = input('Enter the size of the mask (e.g., 3 for a 3x3 mask): ');

% Initialize the mask
w = zeros(m, m);
for i = 1:m
    for j = 1:m
        % Ask user to input the coefficient for each element of the mask
        w(i, j) = input('Enter the Coefficient: ');
    end
end

% Display the entered mask
disp('The mask entered by you is:');
disp(w);

% Calculate the sum of the mask coefficients
sum_mask = sum(w, 'all');

% Determine if it's a high-pass or low-pass filter
if (sum_mask == 0)
    disp('You have entered a high-pass filter.');
elseif (sum_mask == 1)
    disp('You have entered a low-pass filter.');
else
    warning('This is neither a high-pass nor a low-pass filter.');
end

% Show the original image
figure, imshow(uint8(a)), title('Original Image');

% Apply the filter
s = floor(m / 2);  % Half size of the mask
filtered_image = zeros(size(b));

for x = (1 + s):(row - s)
    for y = (1 + s):(col - s)
        % Apply the mask to the local neighborhood
        for i = 1:m
            for j = 1:m
                filtered_image(x, y) = filtered_image(x, y) + w(i, j) * b(x + i - s - 1, y + j - s - 1);
            end
        end
    end
end

% Convert filtered image to uint8 for display
filtered_image = uint8(filtered_image);

% Display the result
figure, imshow(filtered_image), title('Filtered Image');

% Determine if it was a high-pass or low-pass filter
if (sum_mask == 0)
    figure, imshow(filtered_image), title('High-pass Filter Result');
elseif (sum_mask == 1)
    figure, imshow(filtered_image), title('Low-pass Filter Result');
else
    figure, imshow(filtered_image), title('Custom Filter Result');
end