clear all;
close all;
clc;

% Read and convert the image to double precision
a = imread('earth.jpg');
a = double(a);

% Get the size of the image
[row, col] = size(a);

% Define the Laplacian filter
lap = [0 1 0; 1 -4 1; 0 1 0];

% Initialize an empty matrix for the result
c = zeros(row, col);

% Apply the Laplacian filter to the image
for x = 2:row-1
    for y = 2:col-1
        % Compute the convolution manually
        c(x, y) = lap(1,1)*a(x-1, y-1) + lap(1,2)*a(x-1, y) + lap(1,3)*a(x-1, y+1) + ...
                  lap(2,1)*a(x, y-1) + lap(2,2)*a(x, y) + lap(2,3)*a(x, y+1) + ...
                  lap(3,1)*a(x+1, y-1) + lap(3,2)*a(x+1, y) + lap(3,3)*a(x+1, y+1);
    end
end

% Display the original and Laplacian-filtered images
subplot(2,2,1);
imshow(uint8(a));
title('Original Image');

subplot(2,2,2);
imshow(uint8(c));
title('Laplacian Image');