clc;
clear all;
close all;

% Read the image
img = imread('catseeing.jpg');

% Display the original image
subplot(2,2,1); 
imshow(img);
title('Original Image');

% Convert RGB image to grayscale
grayImg = rgb2gray(img);
subplot(2,2,2); 
imshow(grayImg); 
title('Grayscale Image');

% Apply median filter for noise removal
filteredImg = medfilt2(grayImg, [3 3]);
subplot(2,2,3);
imshow(filteredImg);
title('Image after Noise Removal');

% Apply Sobel operator for edge detection
bwSobelImg = edge(filteredImg, 'sobel');
subplot(2,2,4);
imshow(bwSobelImg);
title('Applying Sobel Operator Filter');