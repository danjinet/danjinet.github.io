clc;
clear all;
close all;

% Read the image
i = imread('oldmanwithcats&chicken.jpg');

figure(1);

% Display original image
subplot(5,2,1);
imshow(i);
title('Original Image');

% Convert RGB image to grayscale and double
j = im2double(rgb2gray(i));
subplot(5,2,2);
imshow(j);
title('Grayscale and Double Image');

% Apply mean2 function to calculate the mean
a = mean2(j);
subplot(5,2,3);
imshow(j);  % Since mean2 returns a scalar, display the grayscale image
title(['Mean2: ', num2str(a)]);

% Apply a filter using the mean value
f = imfilter(j, a);
subplot(5,2,4);
imshow(f);
title('Filtered Image with Mean Value');

% Compute the absolute difference between the original grayscale image and filtered image
z = imabsdiff(j, f);
subplot(5,2,5);
imshow(z);
title('Absolute Difference');

% Add Salt and Pepper noise to the image
x = imnoise(j, 'salt & pepper');
subplot(5,2,6);
imshow(x);
title('Noisy Image (Salt & Pepper)');

% Apply an average filter to remove noise
h = fspecial('average', [3 3]);
y = filter2(h, x);
subplot(5,2,7);
imshow(y, []);
title('Average Filter for Noise Removal');

% Apply a median filter for noise removal
b = medfilt2(x);
subplot(5,2,8);
imshow(b);
title('Median Filter for Noise Removal');