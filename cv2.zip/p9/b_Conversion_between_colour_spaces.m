clc;
clear all;
close all;

% Read the color image
img = imread('Lake.jpg');

% Convert the image from RGB to grayscale
grayImg = rgb2gray(img);

% Convert the image from RGB to HSV
hsvImg = rgb2hsv(img);

% Convert the image from RGB to YCbCr
ycbcrImg = rgb2ycbcr(img);

% Display the images in subplots
figure;
subplot(2, 2, 1);
imshow(img);
title('Original Image (RGB)');

subplot(2, 2, 2);
imshow(grayImg);
title('Grayscale Image');

subplot(2, 2, 3);
imshow(hsvImg);
title('HSV Image');

subplot(2, 2, 4);
imshow(ycbcrImg);
title('YCbCr Image');