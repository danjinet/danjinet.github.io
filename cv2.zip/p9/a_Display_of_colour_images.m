clc;
clear all;
close all;

% Read the color image
img = imread('Dogonroad.jpg');

% Display the original color image
figure;
imshow(img);
title('Original Color Image');