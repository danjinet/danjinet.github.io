clc;
clear all;
close all;

% Read the original image
img = imread('redparrot.jpg');

% Convert the image to grayscale
grayImg = rgb2gray(img);

% Create a disk-shaped structuring element with a radius of 10 pixels
se = strel('disk', 10);

% Perform background estimation using morphological opening
bkgnd = imopen(grayImg, se);

% Subtract the background from the grayscale image to flatten the background
subImg = imsubtract(grayImg, bkgnd);

% Create one figure with subplots for all images
figure;

% Display the original image
subplot(1, 3, 1);
imshow(img);
title('Original Image');

% Display the background estimation
subplot(1, 3, 2);
imshow(bkgnd);
title('Background Estimation');

% Display the image with flattened background
subplot(1, 3, 3);
imshow(subImg);
title('Flattened Background');