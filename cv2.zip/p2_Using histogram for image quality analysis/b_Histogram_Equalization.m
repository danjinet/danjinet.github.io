clc;
clear all;
close all;

a = imread('manwithhat.jpg'); 
a = double(a); 
[row, col, d] = size(a); 
c = row * col; 

% Initialize histograms
h = zeros(1, 256);  % Original histogram
z = zeros(1, 256);  % Histogram after equalization

% Ensure no pixel values are 0, replace them with 1
for e = 1:d
    for n = 1:row
        for m = 1:col
            if a(n, m, e) == 0
                a(n, m, e) = 1;
            end
        end
    end
end

% Calculate the histogram for the grayscale image
gray_img = rgb2gray(uint8(a));  % Convert to grayscale
for n = 1:row
    for m = 1:col
        t = gray_img(n, m);  % Get pixel value
        h(t + 1) = h(t + 1) + 1;  % Update histogram count (t+1 for indexing)
    end
end

% Calculate PDF and CDF
pdf = h / c;
cdf = cumsum(pdf);  % Cumulative distribution function (CDF)

% Normalize the CDF and perform histogram equalization
new_values = round(cdf * 255);  % Mapping new pixel values

% Apply the new pixel values (equalization)
b = gray_img;  % Initialize the output image
for p = 1:row
    for q = 1:col
        temp = gray_img(p, q);
        b(p, q) = new_values(temp + 1);  % Apply equalized value
        z(b(p, q) + 1) = z(b(p, q) + 1) + 1;  % Update equalized histogram
    end
end

% Display the original and equalized images and their histograms
subplot(2, 2, 1); 
imshow(uint8(a)); 
title('Original Image');

subplot(2, 2, 2); 
bar(h); 
title('Original Histogram');

subplot(2, 2, 3); 
imshow(uint8(b)); 
title('After Histogram Equalization');

subplot(2, 2, 4); 
bar(z); 
title('Equalized Histogram');