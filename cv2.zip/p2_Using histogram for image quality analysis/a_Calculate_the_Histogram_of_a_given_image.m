clc;
clear all;
close all;

a = imread('manwithhat.jpg');  % Load the image
a = double(a);                % Convert image to double for calculations
[row, col] = size(a);         % Get the size of the image

h = zeros(1, 256);            % Initialize the histogram array for 256 intensity values

% Calculate the histogram
for n = 1:row
    for m = 1:col
        t = a(n,m);           % Get the pixel value
        h(t + 1) = h(t + 1) + 1;  % Update histogram (t+1 since MATLAB indexing starts at 1)
    end
end

% Display the original image and its histogram
figure(1), imshow(uint8(a)), title('Original Image');
figure(2) , bar(0:255, h), title('Histogram'), xlim([0 255]);