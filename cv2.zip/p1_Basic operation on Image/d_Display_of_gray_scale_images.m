clc();
close all;
clear all; 

m = imread('blackgirl.jpg'); 

% Create one figure with multiple subplots
figure;

% Display original image
subplot(2, 3, 1); 
imshow(m);
title('Original Image');

% Convert to grayscale
gray_img = rgb2gray(m); 

% Display the grayscale image with different levels of quantization
subplot(2, 3, 2);
imshow(uint8(floor(double(gray_img)/256 * 128)), gray(128));
title('128 Gray Levels');

subplot(2, 3, 3);
imshow(uint8(floor(double(gray_img)/256 * 64)), gray(64));
title('64 Gray Levels');

subplot(2, 3, 4);
imshow(uint8(floor(double(gray_img)/256 * 32)), gray(32));
title('32 Gray Levels');

subplot(2, 3, 5);
imshow(uint8(floor(double(gray_img)/256 * 16)), gray(16));
title('16 Gray Levels');

subplot(2, 3, 6);
imshow(uint8(floor(double(gray_img)/256 * 8)), gray(8));
title('8 Gray Levels');