clc();
clear all;
close all;

og = imread('mom&baby.jpg');

r = og(:,:,1);  % Red channel
g = og(:,:,2);  % Green channel
b = og(:,:,3);  % Blue channel

subplot(2,2,1), imshow(og), title('Original Image');
subplot(2,2,2), imshow(r), title('Red Channel');
subplot(2,2,3), imshow(g), title('Green Channel');
subplot(2,2,4), imshow(b), title('Blue Channel');