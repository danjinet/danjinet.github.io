clear all,

clc;

close all; 
im=imread('blackgirl.jpg'); 
b=double(im); 
n=255-b; 
subplot(1,2,1) 
imshow(uint8(im)); 
title('Original image'); 
subplot(1,2,2) 
imshow(uint8(n)); 
title('Negation image');