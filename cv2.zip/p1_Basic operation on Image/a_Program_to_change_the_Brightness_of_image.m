clc();
clear all;
close all;

im = imread('flowers.jpg');
a = double(im);  % Convert image to double for calculations
b = a;           % Copy of original image for manipulation

t = input('Enter value for brightness adjustment (positive to brighten): ');

% Get the size of the image including color channels
[r, c, ch] = size(a);

% Loop through each pixel and adjust brightness for each color channel
for x = 1:r
    for y = 1:c
        for z = 1:ch
            b(x, y, z) = a(x, y, z) + t;  % Increase brightness
        end
    end
end

% Display the original and adjusted images
subplot(2,2,1), imshow(uint8(a)), title('Original Image');
subplot(2,2,2), imshow(uint8(b)), title('After Brightness Adjustment');