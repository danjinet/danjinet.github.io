clc;
close all;
clear all;

% Read the input image
io = imread('spacewalk.jpg');

% Convert to double for calculations
in = double(io);

% Get the size of the image
[r, c] = size(in);

% Perform image negation
disp('Negation of image');
for x = 1:r
    for y = 1:c
        in(x, y) = 255 - in(x, y);  % Negate the pixel value
    end
end

% Display the original and negative images
subplot(1,2,1); 
imshow(uint8(io)); 
title('Original Image');

subplot(1,2,2); 
imshow(uint8(in)); 
title('Negative Image');