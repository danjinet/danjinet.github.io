clc;
clear all;
close all;

a = imread('vegetables.jpg');

% Use flip instead of flipdim
hr = flip(a, 2);  % Horizontal flip
vr = flip(a, 1);  % Vertical flip

% Create one figure with subplots for all three images
figure;

% Display original image
subplot(1, 3, 1);
imshow(a);
title('Original Image');

% Display horizontally flipped image
subplot(1, 3, 2);
imshow(hr);
title('Horizontal Flip');

% Display vertically flipped image
subplot(1, 3, 3);
imshow(vr);
title('Vertical Flip');